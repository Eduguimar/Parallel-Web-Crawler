# Parallel Web Crawler

Second project from Java Development Nanodegree at Udacity.

The scaffold project to start comes from https://github.com/udacity/nd079-c2-advanced-java-programming-techniques-projectstarter.

The source code for hypothetical company's legacy web crawler, which is single-threaded. Here, we need to apply the knowledge acquired from the course, using advanced features as multi-threading, reflection, design patterns, AOP (Aspect Orientation Program), Functional Programming and I/O Files (reading and writing from JSON files).
